# This could go in an initializer
FullContact.configure do |config|
    config.api_key = "ca59ff4719c92ffd"
end